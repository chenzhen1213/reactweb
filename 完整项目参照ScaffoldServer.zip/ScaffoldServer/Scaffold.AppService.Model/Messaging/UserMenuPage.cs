﻿using EStart.Infrastructure.Messaging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.Messaging
{
    public class UserMenuPage : GetPagingRequest
    {
        public UserMenuPage(int PageIndex, int PageSize) : base(PageIndex, PageSize)
        {
        }

        public string MenuName { get; set; }


    }
}
