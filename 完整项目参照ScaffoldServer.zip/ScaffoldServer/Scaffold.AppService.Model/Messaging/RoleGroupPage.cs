﻿using EStart.Infrastructure.Messaging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.Messaging
{
    public class RoleGroupPage : GetPagingRequest
    {
        public RoleGroupPage(int PageIndex, int PageSize) : base(PageIndex, PageSize)
        {
        }

        public string RoleGroupName { get; set; }


    }
}
