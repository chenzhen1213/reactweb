﻿using EStart.Infrastructure.Messaging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.Messaging
{
    public class UserActionPage : GetPagingRequest
    {
        public UserActionPage(int PageIndex, int PageSize) : base(PageIndex, PageSize)
        {
        }

        public string ActionName { get; set; }
    }
}
