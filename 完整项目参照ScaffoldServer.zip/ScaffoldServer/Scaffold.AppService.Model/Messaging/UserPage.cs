﻿using EStart.Infrastructure.Messaging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.Messaging
{
    public class UserPage : GetPagingRequest
    {
        public UserPage(int PageIndex, int PageSize) : base(PageIndex, PageSize)
        {
        }


        /// <summary>
        /// 登录名
        /// </summary>
        public string LoginName { get; set; }
        /// <summary>
        /// 真实姓名
        /// </summary>
        public string RealName { get; set; }

        /// <summary>
        /// 手机号
        /// </summary>
        public string Mobile { get; set; }
    }

}
