﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.Models
{
    public class RoleGroupModel
    {
        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 角色组等级
        /// </summary>
        public int RoleDataLevel { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }

        public string guid { get; set; }

        public string CreateTime { get; set; }


        public List<int> Role { get; set; }

    }
}
