﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.Models
{
    public  class CheckModel
    {
        public string label { get; set; }
        public int value { get; set; }
    }
}
