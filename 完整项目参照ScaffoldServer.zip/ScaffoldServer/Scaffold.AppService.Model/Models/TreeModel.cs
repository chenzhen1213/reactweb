﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.Models
{
    public class Tree {
        public List<string> expandKey { get; set; }
        public List<TreeModel> treeModel { get; set; }
    }
    public class TreeModel
    {
        public string title { get; set; }

        public string key { get; set; }

        public bool isLeaf { get; set; }

        public List<TreeModel> children { get; set; }
    }
}
