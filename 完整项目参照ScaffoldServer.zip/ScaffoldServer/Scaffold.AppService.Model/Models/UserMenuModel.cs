﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.Models
{
    public class UserMenuModel
    {

        public int key { get; set; }

        /// <summary>
        /// 所属菜单
        /// </summary>
        public int? FatherID { get; set; }

        /// <summary>
        /// 菜单名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 介绍
        /// </summary>
        public string Introduce { get; set; }

        /// <summary>
        /// 菜单URL
        /// </summary>
        public string Url { get; set; }
        /// <summary>
        /// 图标
        /// </summary>
        public string Icon { get; set; }
        /// <summary>
        /// 是否展开
        /// </summary>
        public bool Spread { get; set; }


        /// <summary>
        /// 排序
        /// </summary>
        public int Sort { get; set; }

        public string guid { get; set; }

        public string CreateTime { get; set; }


        public List<UserMenuModel> children { get; set; }


    }
}
