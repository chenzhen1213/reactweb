﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.RequestModel
{
    public class AdminRequest
    {
        /// <summary>
        /// 登录名
        /// </summary>
        public string LoginName { get; set; }
        /// <summary>
        /// 密码
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 管理员名称
        /// </summary>
        public string AdminName { get; set; }

        /// <summary>
        /// 电话
        /// </summary>
        public string PhoneNum { get; set; }

    }
}
