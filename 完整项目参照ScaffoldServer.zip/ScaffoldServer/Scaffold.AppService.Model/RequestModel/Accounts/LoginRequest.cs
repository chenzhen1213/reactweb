﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.RequestModel
{
    public class LoginRequest
    {
        public string LoginName { get; set; }
        public string Password { get; set; }
    }
}
