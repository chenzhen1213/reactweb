﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.RequestModel
{
    public class LogoutReqeust
    {
        public Guid Guid { get; set; }
    }
}
