﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.RequestModel
{
    public class UserRequest
    {
        /// <summary>
        /// 登录名
        /// </summary>
        public string LoginName { get; set; }
        /// <summary>
        /// 密码
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 真实姓名
        /// </summary>
        public string RealName { get; set; }

        /// <summary>
        /// 手机号
        /// </summary>
        public string Mobile { get; set; }


        /// <summary>
        /// 选择的校区
        /// </summary>
        public string SchoolGuid { get; set; }

        /// <summary>
        /// 座机号
        /// </summary>
        public string Tel { get; set; }


        public string guid { get; set; }


        public List<int> RoleGroup { get; set; }


    }
}
