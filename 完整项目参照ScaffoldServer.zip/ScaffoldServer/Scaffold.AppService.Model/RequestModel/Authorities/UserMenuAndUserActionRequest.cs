﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.RequestModel
{
    public  class UserMenuAndUserActionRequest
    {
        /// <summary>
        /// 菜单和动作集合
        /// </summary>
        public List<string> MenuAndActionList { get; set; }

        /// <summary>
        /// roleguid
        /// </summary>
        public string guid { get; set; }
    }
}
