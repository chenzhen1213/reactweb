﻿using EStart.Infrastructure.Messaging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.RequestModel
{
    public class GetUserActionPagesRequest : GetPagingRequest
    {
        public GetUserActionPagesRequest(int pageIndex, int pageSize) : base(pageIndex, pageSize)
        {
        }
        public string Name { get; set; }
    }
}
