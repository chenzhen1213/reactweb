﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.RequestModel
{
    public class DepartmentRequest
    {
        /// <summary>
        /// 
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 扭转期
        /// </summary>
        public int Overdue { get; set; }


        /// <summary>
        /// 主键guid
        /// </summary>
        public string guid { get; set; }
    }
}
