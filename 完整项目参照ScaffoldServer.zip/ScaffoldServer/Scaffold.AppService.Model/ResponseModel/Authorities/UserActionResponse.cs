﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.ResponseModel
{
    public class UserActionResponse
    {
        public int id { get; set; }

        public string name { get; set; }

    }
}
