﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.ResponseModel
{
    public class LoginResponse
    {
        public string LoginName { get; set; }
        public string RealName { get; set; }
        public Guid Guid { get; set; }
        public Guid SignToken { get; set; }
        public IList<LoginMenu> Menus { get; set; }
    }
    public class LoginMenu
    {
        public int Id { get; set; }
        public string MenuName { get; set; }
        public string Url { get; set; }
        public IList<LoginMenu> Children { get; set; }
        public IList<LoginAction> Actions { get; set; }
        public int ParentId { get; set; }
    }
    public class LoginAction
    {
        public string ActionName { get; set; }
        public string Parameter { get; set; }
    }
}
