﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.ResponseModel
{
    public  class BaiPingSchoolResponse
    {
        public string SchoolName { get; set; }

        public int Overdue { get; set; }

        public string Guid { get; set; }

        public string CreateTime { get; set; }

    }
}
