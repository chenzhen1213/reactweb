﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.AppService.Model.ResponseModel
{
    public  class DepartmentResponse
    {
        public string Name { get; set; }

        public int Overdue { get; set; }

        public string Guid { get; set; }

        public string CreateTime { get; set; }

    }
}
