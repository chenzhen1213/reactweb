﻿
using EStart.DataBase.Event.Domian;
using EStart.DataBase.Event.Domian.EntityEnum;
using EStart.Infrastructure;
using EStart.Infrastructure.Domain;
using EStart.Interface;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace QuickApp.Domain
{
    /// <summary>
    /// 工作单元
    /// </summary>
    public class UnitOfWork : IUnitOfWork
    {
        private Guid TransGuid { get; set; } = Guid.NewGuid();
        public DbContext dbContext { private get; set; }
        public EventDbContext eventDbContext { private get; set; }

        public void RegisterNew<TEntity>(TEntity entity)
             where TEntity : EntityCore
        {
            ThrowExceptionIfEntityIsInvalid(entity);
            dbContext.Set<TEntity>().Add(entity);
            SaveEventSource(entity, "", entity.ToJsonSerialize(), EventType.Insert);
        }
        public async Task RegisterNewAsync<TEntity>(TEntity entity)
        where TEntity : EntityCore
        {
            ThrowExceptionIfEntityIsInvalid(entity);
            await dbContext.Set<TEntity>().AddAsync(entity);
            SaveEventSource(entity, "", entity.ToJsonSerialize(), EventType.Insert);
        }
        public void RegisterNewRange<TEntity>(IEnumerable<TEntity> entities) where TEntity : EntityCore
        {
            if (entities == null || entities.Count() == 0)
                throw new ArgumentNullException(nameof(entities));
            foreach (var entity in entities)
            {
                ThrowExceptionIfEntityIsInvalid(entity);
            }
            dbContext.Set<TEntity>().AddRange(entities);
            SaveEventSource<TEntity>(null, "", entities.ToJsonSerialize(), EventType.InsertRange);
        }

        public async Task RegisterNewRangeAsync<TEntity>(IEnumerable<TEntity> entities) where TEntity : EntityCore
        {
            if (entities == null || entities.Count() == 0)
                throw new ArgumentNullException(nameof(entities));
            foreach (var entity in entities)
            {
                ThrowExceptionIfEntityIsInvalid(entity);
            }
            await dbContext.Set<TEntity>().AddRangeAsync(entities);
            SaveEventSource<TEntity>(null, "", entities.ToJsonSerialize(), EventType.InsertRange);
        }
        public void RegisterDirty<TEntity>(TEntity entity)
            where TEntity : EntityCore
        {
            ThrowExceptionIfEntityIsInvalid(entity);
            var entry = dbContext.Entry(entity);
            entry.State = EntityState.Modified;
            entity.LastChangeTime = DateTime.Now;
            SaveEventSource(entity, PropertyValuesToModel(entry.OriginalValues), PropertyValuesToModel(entry.CurrentValues), EventType.Update);
        }


        public void RegisterClean<TEntity>(TEntity entity)
            where TEntity : EntityCore
        {
            var entry = dbContext.Entry(entity);
            entry.State = EntityState.Unchanged;
        }

        public void RegisterDeleted<TEntity>(TEntity entity)
            where TEntity : EntityCore
        {
            dbContext.Set<TEntity>().Remove(entity);
            SaveEventSource(entity, entity.ToJsonSerialize(), "", EventType.Delete);
        }

        public async Task<bool> CommitAsync()
        {
            var isSuccess = await dbContext.SaveChangesAsync() > 0;
            try
            {
                if (isSuccess)
                {
                    eventDbContext.SaveChanges();
                }
            }
            catch (Exception)
            {

            }
            return isSuccess;
        }

        public void Rollback()
        {
            throw new NotImplementedException();
        }

        public bool Commit()
        {
            var isSuccess = dbContext.SaveChanges() > 0;
            try
            {
                if (isSuccess)
                {
                    eventDbContext.SaveChanges();
                }
            }
            catch (Exception)
            {

            }

            return isSuccess;
        }

        private string PropertyValuesToModel(PropertyValues values)
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("{");
            foreach (var propertyName in values.Properties)
            {
                stringBuilder.Append(string.Format("\"{0}\": \"{1}\",", propertyName.Name, values[propertyName.Name]));
            }
            var rstring = stringBuilder.ToString().TrimEnd(',') + "}";
            return rstring;
        }
        private void SaveEventSource<TEntity>(TEntity entity, string beforeEntity, string behidEntity, EventType eventType) where TEntity : EntityCore
        {
            try
            {
                if (eventDbContext != null)
                {
                    EventSource eventSource = new EventSource();
                    eventSource.BeforeEntity = beforeEntity;
                    eventSource.BehindEnitiy = behidEntity;
                    eventSource.DbContentName = dbContext.GetType().Name;
                    eventSource.EventType = eventType;
                    if (entity != null)
                    {
                        eventSource.ModelGuid = entity.Guid;
                        eventSource.ModelName = entity.GetType().Name;
                    }
                    eventSource.TransGuid = TransGuid;
                    eventDbContext.Add(eventSource);
                }
            }
            catch (Exception)
            {


            }

        }


        /// <summary>
        /// 验证数据的正确性
        /// </summary>
        /// <param name="entity">实体</param>
        private void ThrowExceptionIfEntityIsInvalid<TEntity>(TEntity entity) where TEntity : EntityCore
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));
            if (entity.GetBrokenRules().Any())
            {
                var brokenRules = new StringBuilder();
                brokenRules.AppendLine("数据验证不通过，错误信息：");
                foreach (var businessRule in entity.GetBrokenRules())
                {
                    brokenRules.AppendLine(businessRule.Rule);
                }
                throw new Exception(brokenRules.ToString());
            }
        }
    }
}
