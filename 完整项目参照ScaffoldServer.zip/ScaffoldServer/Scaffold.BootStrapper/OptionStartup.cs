﻿

using Scaffold.Domain;
using EStart.DataBase.Event.Domian;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Scaffold.BootStrapper
{
    public static class OptionStartup
    {


        /// <summary>
        /// 初始化Scaffold服务
        /// </summary>
        /// <param name="services"></param>
        /// <param name="connstring">上下文链接字符串</param>
        /// <param name="eventconnstring">事件日志链接字符串</param>
        /// <returns></returns>
        public static IServiceCollection ScaffoldInit(this IServiceCollection services, string connstring, string eventconnstring)
        {

            if (!string.IsNullOrEmpty(eventconnstring))
            {
                //配置事件日志数据库
                services.AddDbContext<EventDbContext>(options =>
                 options.UseSqlServer(eventconnstring, p => p.MigrationsAssembly("EStart.DataBase.Event.Domian")));
            }
            //配置DI容器
            ScaffoldIocConfiguration.AddIocConfiguration(services);

            services.AddDbContext<ScaffoldDbContext>(options =>
             options.UseSqlServer(connstring, p => p.MigrationsAssembly("Scaffold.Domain")));

            return services;
        }

    }
}
