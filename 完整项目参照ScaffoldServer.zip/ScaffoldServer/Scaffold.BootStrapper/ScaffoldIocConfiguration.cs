using Scaffold.AppService.Implements;
using Scaffold.AppService.Interfaces;
using EStart.Infrastructure.Caching;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.BootStrapper
{
    public static partial class ScaffoldIocConfiguration
    {
        /// <summary>
        /// 注册DI服务
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddIocConfiguration(IServiceCollection services)
        {
   
            services = AddIocBase(services);
            services.AddTransient<ICacheManager, MemoryCacheAdapter>();
            //services.AddTransient<IDomainEventPublisher, DomainEventPublisher>();
            //services.AddTransient<IDomainEventHandler<UserEvent>, EventHandlerTest>();
            //services.AddTransient<IDomainEventHandler<UserEvent>, EventHandlerCaching>();

            return services;
        }
    }
}
