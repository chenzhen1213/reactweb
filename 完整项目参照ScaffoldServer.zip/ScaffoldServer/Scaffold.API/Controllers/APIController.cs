﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EStart.Infrastructure.ClientData;
using Scaffold.API.Authentication;
using EStart.Infrastructure.Engines;
using EStart.Infrastructure.Caching;
using Scaffold.API.Filters;

namespace Scaffold.API.Controllers
{
    [APISecurityFilter]
    public class APIController : Controller
    {
        
    }
}
