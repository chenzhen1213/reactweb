﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Scaffold.AppService.Model.RequestModel;
using EStart.Infrastructure.ClientData;
using Scaffold.AppService.Implements;
using Scaffold.AppService.Interfaces;
using Scaffold.API.Authentication;
using EStart.Infrastructure.Domain;
using Scaffold.AppService.Model.Messaging;
using Scaffold.AppService.Model.Models;

namespace Scaffold.API.Controllers
{
    [Produces("application/json")]
    [Route("api/role")]
    public class RoleController : APIController
    {
        private readonly IRoleService _Service;

        public RoleController(IRoleService Service)
        {
            _Service = Service;
        }

        [HttpPost("create")]
        public async Task<ApiResult<string>> Create([FromBody]RoleModel request)
        {
            return await _Service.SaveAsync(request);
        }
        [HttpPost("update")]
        public async Task<ApiResult<string>> Update([FromBody]RoleModel request)
        {
            return await _Service.SaveAsync(request);
        }


        [HttpPost("getpages")]
        public async Task<ApiResult<Page<RoleModel>>> GetPages([FromBody]RolePage request)
        {
            return await _Service.GetPagesAsync(request);
        }


        [HttpGet("getdetail")]
        public ApiResult<RoleModel> GetDetail(string guid)
        {
            var schoolGuid = Guid.Parse(guid);
            return _Service.GetDetail(schoolGuid);
        }


        [HttpPost("delete")]
        public ApiResult<string> Delete([FromBody]RoleModel request)
        {
            var sGuid = Guid.Parse(request.guid);
            return _Service.Delete(sGuid);
        }


        [HttpGet("getcheckmodel")]
        public async Task<ApiResult<List<CheckModel>>> GetCheckModel()
        {

            return await _Service.GetCheckModelAsync();
        }

        [HttpPost("menubind")]
        public async Task<ApiResult<string>> MenuBind([FromBody]UserMenuAndUserActionRequest request)
        {
            return await _Service.SaveUseMenuAsync(request);
        }
        [HttpGet("getcheckbyroleguid")]
        public async Task<ApiResult<List<string>>> GetCheckByRoleGuid(string guid)
        {
            var roleguid = Guid.Parse(guid);
            return await _Service.GetCheckByRoleGuid(roleguid);
        }

    }
}