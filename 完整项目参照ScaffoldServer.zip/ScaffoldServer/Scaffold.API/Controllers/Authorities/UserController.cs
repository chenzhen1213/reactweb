﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Scaffold.AppService.Model.RequestModel;
using EStart.Infrastructure.ClientData;
using Scaffold.AppService.Implements;
using Scaffold.AppService.Interfaces;
using Scaffold.API.Authentication;
using EStart.Infrastructure.Domain;
using Scaffold.AppService.Model.Messaging;
using Scaffold.AppService.Model.ResponseModel;
using Scaffold.Domain.Model;

namespace Scaffold.API.Controllers
{
    [Produces("application/json")]
    [Route("api/user")]
    public class UserController : APIController
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost("create")]
        public async Task<ApiResult<string>> Create([FromBody]UserRequest request)
        {
            return await _userService.SaveAsync(request);
        }
        [HttpPost("update")]
        public async Task<ApiResult<string>> Update([FromBody]UserRequest request)
        {
            return await _userService.SaveAsync(request);
        }


        [HttpPost("getpages")]
        public async Task<ApiResult<Page<UserResponse>>> GetPages([FromBody]UserPage request)
        {
            return await _userService.GetPagesAsync(request);
        }


        [HttpGet("getdetail")]
        public ApiResult<UserResponse> GetDetail(string guid)
        {
            var schoolGuid = Guid.Parse(guid);
            return _userService.GetDetail(schoolGuid);
        }


        [HttpPost("delete")]
        public ApiResult<string> Delete([FromBody]UserRequest request)
        {
            var schoolGuid = Guid.Parse(request.guid);
            return _userService.Delete(schoolGuid);
        }

    }
}