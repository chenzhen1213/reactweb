﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Scaffold.AppService.Model.RequestModel;
using EStart.Infrastructure.ClientData;
using Scaffold.AppService.Implements;
using Scaffold.AppService.Interfaces;
using Scaffold.API.Authentication;
using EStart.Infrastructure.Domain;
using Scaffold.AppService.Model.Messaging;
using Scaffold.AppService.Model.Models;
using Scaffold.AppService.Model.ResponseModel;

namespace Scaffold.API.Controllers
{
    [Produces("application/json")]
    [Route("api/usermenu")]
    public class UserMenuController : APIController
    {
        private readonly IUserMenuService _Service;

        public UserMenuController(IUserMenuService Service)
        {
            _Service = Service;
        }

        [HttpPost("create")]
        public async Task<ApiResult<string>> Create([FromBody]UserMenuModel request)
        {
            return await _Service.SaveAsync(request);
        }
        [HttpPost("update")]
        public async Task<ApiResult<string>> Update([FromBody]UserMenuModel request)
        {
            return await _Service.SaveAsync(request);
        }

        [HttpPost("getpages")]
        public async Task<ApiResult<Page<UserMenuModel>>> GetPages([FromBody]UserMenuPage request)
        {
            return await _Service.GetPagesAsync(request);
        }


        [HttpGet("getdetail")]
        public ApiResult<UserMenuModel> GetDetail(string guid)
        {
            var schoolGuid = Guid.Parse(guid);
            return _Service.GetDetail(schoolGuid);
        }


        [HttpPost("delete")]
        public ApiResult<string> Delete([FromBody]UserMenuModel request)
        {
            var sGuid = Guid.Parse(request.guid);
            return _Service.Delete(sGuid);
        }


        [HttpGet("getfathermenu")]
        public ApiResult<List<UserActionResponse>> GetFathermenu()
        {

            return _Service.GetFatherMenu();
        }
        [HttpGet("getcheckmodel")]
        public async Task<ApiResult<Tree>> GetCheckModel()
        {

            return await _Service.GetCheckModelAsync();
        }
    }
}