﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EStart.Infrastructure.ClientData;
using Scaffold.AppService.Model.RequestModel;
using Scaffold.AppService.Interfaces;
using Scaffold.AppService.Model.Messaging;
using Scaffold.AppService.Model.ResponseModel;
using EStart.Infrastructure.Domain;

namespace Scaffold.API.Controllers
{
    [Produces("application/json")]
    [Route("api/department")]
    public class DepartmentController : APIController
    {
        private readonly IDepartmentService _Service;

        public DepartmentController(IDepartmentService Service)
        {
            _Service = Service;
        }
        [HttpPost("create")]
        public async Task<ApiResult<string>> Create([FromBody]DepartmentRequest request)
        {
            return await _Service.SaveAsync(request);
        }
        [HttpPost("update")]
        public async Task<ApiResult<string>> Update([FromBody]DepartmentRequest request)
        {
            return await _Service.SaveAsync(request);
        }


        [HttpPost("getpages")]
        public async Task<ApiResult<Page<DepartmentResponse>>> GetPages([FromBody]DepartmentPage request)
        {
            return await _Service.GetPagesAsync(request);
        }


        [HttpGet("getdetail")]
        public ApiResult<DepartmentResponse> GetDetail(string guid)
        {
            var schoolGuid = Guid.Parse(guid);
            return _Service.GetDetail(schoolGuid);
        }
        [HttpGet("getall")]
        public ApiResult<List<DepartmentResponse>> GetAll()
        {
   
            return _Service.GetAllSchool();
        }


        [HttpPost("delete")]
        public ApiResult<string> Delete([FromBody]DepartmentRequest request)
        {
            var schoolGuid = Guid.Parse(request.guid);
            return _Service.Delete(schoolGuid);
        }
    }
}