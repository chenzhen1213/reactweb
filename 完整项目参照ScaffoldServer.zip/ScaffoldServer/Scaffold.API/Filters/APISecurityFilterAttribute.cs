﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using EStart.Infrastructure.ClientData;
using System.Web;
using Scaffold.API.Authentication;
using EStart.Infrastructure.Caching;
using EStart.Infrastructure.Engines;
using System.Collections.Specialized;
using System.Text;
using System.IO;
using Scaffold.API.Helper;
using Scaffold.AppService.Model.ResponseModel;

namespace Scaffold.API.Filters
{
    public class APISecurityFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            ApiResult<string> result = null;
            var request = context.HttpContext.Request;
            string method = request.Method;
            // 当前请求的控制器名称
            var actionName = context.ActionDescriptor.RouteValues["action"];
            var controllerName = context.ActionDescriptor.RouteValues["controller"];
            // 要过滤的action
            var ignoreActions = new List<string>
                {
                    "Login",
                    "Logout"
                };

            #region Token Validate
            string staffid = String.Empty,
                timestamp = string.Empty,
                nonce = string.Empty,
                signature = string.Empty;
            Guid id = Guid.NewGuid();

            #region GET headers params
            var hStaffid = context.HttpContext.Request.Headers["staffid"];
            if (hStaffid.Count > 0)
            {
                staffid = HttpUtility.UrlDecode(hStaffid.FirstOrDefault());
            }
            var hTimestamp = context.HttpContext.Request.Headers["timestamp"];
            if (hTimestamp.Count > 0)
            {
                timestamp = HttpUtility.UrlDecode(hTimestamp.FirstOrDefault());
            }
            var hNonce = context.HttpContext.Request.Headers["nonce"];
            if (hNonce.Count > 0)
            {
                nonce = HttpUtility.UrlDecode(hNonce.FirstOrDefault());
            }
            var hSignature = context.HttpContext.Request.Headers["signature"];
            if (hSignature.Count > 0)
            {
                signature = HttpUtility.UrlDecode(hSignature.FirstOrDefault());
            }
            #endregion

            if (ignoreActions.Any(p => p == actionName))
            {
                if (string.IsNullOrEmpty(staffid) || (!Guid.TryParse(staffid, out id) || string.IsNullOrEmpty(timestamp) || string.IsNullOrEmpty(nonce)))
                {
                    result = new ApiResult<string>
                    {
                        statusCode = (int)StatusCodeEnum.ParameterError,
                        message = StatusCodeEnum.ParameterError.GetEnumText(),
                        data = ""
                    };
                    context.Result = new JsonResult(result);
                    base.OnActionExecuting(context);
                    return;
                }
                else
                {
                    base.OnActionExecuting(context);
                    return;
                }
            }
            //判断请求头是否包含以下参数
            if (string.IsNullOrEmpty(staffid) ||
                (!Guid.TryParse(staffid, out id) ||
                string.IsNullOrEmpty(timestamp) ||
                string.IsNullOrEmpty(nonce) ||
                string.IsNullOrEmpty(signature)))
            {
                result = new ApiResult<string>
                {
                    statusCode = (int)StatusCodeEnum.ParameterError,
                    message = StatusCodeEnum.ParameterError.GetEnumText(),
                    data = ""
                };
                context.Result = new JsonResult(result);
                base.OnActionExecuting(context);
                return;
            }
            //判断timespan是否有效
            double ts2 = (DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalMilliseconds;
            bool timespanvalidate = double.TryParse(timestamp, out double ts1);
            double ts = ts2 - ts1;
            var urlExpireTime = 120;//后期需读取配置文件
            bool falg = ts > urlExpireTime * 1000;
            if (falg || (!timespanvalidate))
            {
                result = new ApiResult<string>
                {
                    statusCode = (int)StatusCodeEnum.URLExpireError,
                    message = StatusCodeEnum.URLExpireError.GetEnumText(),
                    data = ""
                };
                context.Result = new JsonResult(result);
                base.OnActionExecuting(context);
                return;
            }

            //判断token是否有效
            var cacheManager = EngineContainerFactory.Context.GetInstance<ICacheManager>();
            var token = cacheManager.Get<Token>(id.ToString());
            string signtoken = string.Empty;
            if (token == null)
            {
                result = new ApiResult<string>
                {
                    statusCode = (int)StatusCodeEnum.TokenInvalid,
                    message = StatusCodeEnum.TokenInvalid.GetEnumText(),
                    data = ""
                };
                context.Result = new JsonResult(result);
                base.OnActionExecuting(context);
                return;
            }
            else
            {
                signtoken = token.SignToken.ToString();
            }
            // 验证 Token
            bool r = SignExtension.Validate(timestamp, nonce, id, signtoken, signature);
            if (!r)
            {
                result = new ApiResult<string>
                {
                    statusCode = (int)StatusCodeEnum.HttpRequestError,
                    message = StatusCodeEnum.HttpRequestError.GetEnumText(),
                    data = ""
                };
                context.Result = new JsonResult(result);
                base.OnActionExecuting(context);
                return;
            }
            #endregion

            #region Authorization Validate
            // 如果不是get请求，就需要验证
            if (method.ToUpper() == "GET")
            {
                base.OnActionExecuting(context);
                return;
            }
            //需要忽视验证的控制器集合
            var ignoreControllers = new List<string>
                {
                    "Account"
                };
            if (!ignoreControllers.Any(p => p == controllerName))
            {
                // 当前用户所拥有的菜单权限
                var menus = MemoryCacheHelper.GetPower(token.StaffId.ToString());
                var children = new List<LoginMenu>();
                foreach (var menu in menus)
                {
                    foreach (var child in menu.Children)
                    {
                        children.Add(child);
                    }
                }
                var m = children.FirstOrDefault(p => p.Url == $"/{controllerName.ToLower()}");
                // 菜单未授权
                if (m == null)
                {
                    result = new ApiResult<string>
                    {
                        statusCode = 403,
                        message = "No operation authority.",
                    };
                    context.Result = new JsonResult(result);
                    base.OnActionExecuting(context);
                    return;
                }
      
                    // 要过滤的action 
                    var ignoreActionScopes = new List<string> {
                        "GetPages"
                    };
                    // 排除过滤
                    if (!ignoreActionScopes.Any(p => p.ToLower() == actionName.ToLower()))
                    {
                        var actions = m.Actions;
                        if (!actions.Any(p => p.Parameter.ToLower() == actionName.ToLower()))
                        {
                            result = new ApiResult<string>
                            {
                                statusCode = 403,
                                message = "No operation authority.",
                            };
                            context.Result = new JsonResult(result);
                            base.OnActionExecuting(context);
                            return;
                        }
                    }
                }
            
            #endregion

            // 如果以上验证都不拦截则直接放行.
            base.OnActionExecuting(context);
        }
    }
}
