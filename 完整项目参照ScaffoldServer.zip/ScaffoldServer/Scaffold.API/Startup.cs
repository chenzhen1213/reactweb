﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using StructureMap;
using EStart.Infrastructure.Engines;
using Swashbuckle.AspNetCore.Swagger;
using Microsoft.Extensions.PlatformAbstractions;
using System.IO;
using Scaffold.BootStrapper;


namespace Scaffold.API
{
    public class Startup
    {

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            var connectionString = Configuration.GetConnectionString("DefaultConnection");
            var eventConnectionString = Configuration.GetConnectionString("EventConnection");
            services.AddMvc();
            services.ScaffoldInit(connectionString, eventConnectionString);
            // Add cors
            services.AddCors(options => options.AddPolicy("CorsScaffold",
                p => //p.WithOrigins("http://localhost:8000/")
                p.AllowAnyMethod()
                .AllowAnyHeader()
                .AllowAnyOrigin()
                .AllowCredentials()));
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info
                {
                    Title = "API Docs",
                    Version = "v1",
                    Description = "这是文档的详细信息..",
                    License = new License
                    {
                        Name = "MIT",
                        Url = "https://mit-license.org/"
                    },
                    Contact = new Contact
                    {
                        Name = "Ambre/Van",
                        Url = "http://test.hourxu.com"
                    }
                });
                c.DescribeAllEnumsAsStrings();
                c.DescribeStringEnumsInCamelCase();
            });
            //StructureMap
            var container = new Container();

            // Register stuff in container, using the StructureMap APIs...
            //container.Configure(config => config.Populate(services));
            container.Populate(services);
            EngineContainerFactory.InitializeEngineContainerFactory(new EStart.Infrastructure.Engines.EngineContainer(container));

            return container.GetInstance<IServiceProvider>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();

            app.UseMvc();

            app.UseCors("CorsScaffold");

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "API Docs V1");
            });


        }

        private string GetXmlCommentsPath()
        {
            var app = PlatformServices.Default.Application;
            return Path.Combine(app.ApplicationBasePath, Path.ChangeExtension(app.ApplicationName, "xml"));
        }
    }
}
