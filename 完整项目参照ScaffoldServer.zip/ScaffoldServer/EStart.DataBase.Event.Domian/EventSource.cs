﻿using EStart.DataBase.Event.Domian.EntityEnum;
using EStart.Infrastructure.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace EStart.DataBase.Event.Domian
{
    public class EventSource : EntityCore
    {
        /// <summary>
        /// 操作类型
        /// </summary>
        public EventType EventType { get; set; }

        /// <summary>
        /// 操作前数据
        /// </summary>
        public string BeforeEntity { get; set; }

        /// <summary>
        /// 操作后数据
        /// </summary>
        public string BehindEnitiy { get; set; }

        /// <summary>
        /// 模型名称
        /// </summary>
        public string ModelName { get; set; }

        /// <summary>
        /// 事务GUID
        /// </summary>
        public Guid TransGuid { get; set; }

        /// <summary>
        /// 数据对应GUID
        /// </summary>
        public Guid ModelGuid { get; set; }


        /// <summary>
        /// 上下文名称
        /// </summary>
        public string DbContentName { get; set; }


        protected override void Validate()
        {

        }
    }
}
