﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using EStart.DataBase.Event.Domian;

namespace EStart.DataBase.Event.Domian
{
    public class EventDbContext : DbContext
    {
        public EventDbContext(DbContextOptions<EventDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EventSource>().ToTable("EventSources").Property(p => p.RowVersion).IsRowVersion();
        }
    }
}
