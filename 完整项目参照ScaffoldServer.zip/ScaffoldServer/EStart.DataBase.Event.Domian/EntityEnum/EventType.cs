﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EStart.DataBase.Event.Domian.EntityEnum
{
    public enum EventType
    {
        Insert = 1,
        Update = 2,
        Delete = 3,
        InsertRange = 4,
        DeleteForge = 5
    }
}
