﻿using EStart.Infrastructure.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EStart.Interface
{
    public interface IUnitOfWork
    {
        void RegisterNew<TEntity>(TEntity entity)
       where TEntity : EntityCore;

        void RegisterDirty<TEntity>(TEntity entity)
            where TEntity : EntityCore;

        void RegisterClean<TEntity>(TEntity entity)
            where TEntity : EntityCore;

        void RegisterDeleted<TEntity>(TEntity entity)
            where TEntity : EntityCore;

        Task<bool> CommitAsync();

        bool Commit();

        void Rollback();
    }
}
