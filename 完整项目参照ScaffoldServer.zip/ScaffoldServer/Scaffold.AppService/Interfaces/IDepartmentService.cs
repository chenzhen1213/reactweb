﻿using Scaffold.AppService.Model.Messaging;
using Scaffold.AppService.Model.RequestModel;
using Scaffold.AppService.Model.ResponseModel;
using Scaffold.Domain.Model;
using EStart.Infrastructure.ClientData;
using EStart.Infrastructure.Domain;
using EStart.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Scaffold.AppService.Interfaces
{
    public partial interface IDepartmentService : IServiceCore<Department>
    {
        Task<ApiResult<string>> SaveAsync(DepartmentRequest request);

        Task<ApiResult<Page<DepartmentResponse>>> GetPagesAsync(DepartmentPage request);
        ApiResult<List<DepartmentResponse>> GetAllSchool();

        ApiResult<DepartmentResponse> GetDetail(Guid guid);

        ApiResult<string> Delete(Guid guid);
    }
}
