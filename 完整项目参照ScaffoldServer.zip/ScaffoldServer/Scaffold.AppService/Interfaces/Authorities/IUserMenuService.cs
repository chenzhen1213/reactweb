﻿using Scaffold.AppService.Model.Messaging;
using Scaffold.AppService.Model.Models;
using Scaffold.AppService.Model.RequestModel;
using Scaffold.AppService.Model.ResponseModel;
using Scaffold.Domain.Model;
using EStart.Infrastructure.ClientData;
using EStart.Infrastructure.Domain;
using EStart.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Scaffold.AppService.Interfaces
{
    public partial interface IUserMenuService : IServiceCore<UserMenu>
    {

        Task<ApiResult<string>> SaveAsync(UserMenuModel request);

        Task<ApiResult<Page<UserMenuModel>>> GetPagesAsync(UserMenuPage request);

        ApiResult<UserMenuModel> GetDetail(Guid guid);

        ApiResult<List<UserActionResponse>> GetFatherMenu();


        ApiResult<string> Delete(Guid guid);

        Task<ApiResult<Tree>> GetCheckModelAsync();
    }
}
