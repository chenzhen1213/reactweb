﻿using Scaffold.AppService.Model.Messaging;
using Scaffold.AppService.Model.Models;
using Scaffold.AppService.Model.RequestModel;
using Scaffold.AppService.Model.ResponseModel;
using Scaffold.Domain.Model;
using EStart.Infrastructure.ClientData;
using EStart.Infrastructure.Domain;
using EStart.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Scaffold.AppService.Interfaces
{
    public partial interface IRoleService : IServiceCore<Role>
    {

        Task<ApiResult<string>> SaveAsync(RoleModel request);

        Task<ApiResult<Page<RoleModel>>> GetPagesAsync(RolePage request);

        ApiResult<RoleModel> GetDetail(Guid guid);

        ApiResult<string> Delete(Guid guid);

        Task<ApiResult<List<CheckModel>>> GetCheckModelAsync();


        Task<ApiResult<string>> SaveUseMenuAsync(UserMenuAndUserActionRequest request);

        Task<ApiResult<List<string>>> GetCheckByRoleGuid(Guid guid);


    }
}
