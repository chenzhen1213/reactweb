﻿using Scaffold.AppService.Model.Messaging;
using Scaffold.AppService.Model.Models;
using Scaffold.AppService.Model.RequestModel;
using Scaffold.AppService.Model.ResponseModel;
using Scaffold.Domain.Model;
using EStart.Infrastructure.ClientData;
using EStart.Infrastructure.Domain;
using EStart.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Scaffold.AppService.Interfaces
{
    public partial interface IUserMenuOrActionInRoleService : IServiceCore<UserMenuOrActionInRole>
    {
    }
}
