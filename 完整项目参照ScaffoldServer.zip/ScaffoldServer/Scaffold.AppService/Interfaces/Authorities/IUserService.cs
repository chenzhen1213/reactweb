﻿using Scaffold.AppService.Model.Messaging;
using Scaffold.AppService.Model.RequestModel;
using Scaffold.AppService.Model.ResponseModel;
using Scaffold.Domain.Model;
using EStart.Infrastructure.ClientData;
using EStart.Infrastructure.Domain;
using EStart.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Scaffold.AppService.Interfaces
{
    public partial interface IUserService : IServiceCore<User>
    {

        Task<ApiResult<string>> SaveAsync(UserRequest request);

        Task<ApiResult<Page<UserResponse>>> GetPagesAsync(UserPage request);

        ApiResult<UserResponse> GetDetail(Guid guid);

        ApiResult<string> Delete(Guid guid);

        Task<ApiResult<LoginResponse>> LoginAsync(LoginRequest request);

        Task<IList<LoginMenu>> GetMenusByGuidAsync(Guid guid);
    }
}
