﻿using Scaffold.AppService.Interfaces;
using Scaffold.Domain;
using Scaffold.Domain.Model;
using EStart.DataBase.EF;
using EStart.DataBase.Event.Domian;
using System;
using System.Collections.Generic;
using System.Text;
using Scaffold.AppService.Model.RequestModel;
using EStart.Infrastructure.ClientData;
using System.Threading.Tasks;
using Scaffold.AppService.Model.ResponseModel;
using EStart.Infrastructure.Domain;
using System.Linq;
using EStart.Infrastructure.Extensions;
using Scaffold.AppService.Model.Messaging;
using Scaffold.AppService.Extensions;

namespace Scaffold.AppService.Implements
{
    public partial class DepartmentService : ServiceCore<Department>, IDepartmentService
    {

        public DepartmentService(
            ScaffoldDbContext context,
            EventDbContext eventDbContext
            ) : base(context, eventDbContext)
        {

        }

        public async Task<ApiResult<Page<DepartmentResponse>>> GetPagesAsync(DepartmentPage request)
        {
            ApiResult<Page<DepartmentResponse>> response = new ApiResult<Page<DepartmentResponse>>();
            try
            {
                var pages = await Query()
                            .HasWhere(request.Name, n => n.Name.Contains(request.Name))
                            .Select(n => new DepartmentResponse
                            {
                                Name = n.Name,
                                Overdue = n.Overdue,
                                CreateTime = n.CreateTime.ToString("yyyy-MM-dd HH:mm:ss"),
                                Guid = n.Guid.ToString()
                            }).OrderByDescending(n => n.CreateTime).ToPageAsync(request.PageIndex, request.PageSize);

                response.success = true;
                response.message = "获取成功！";
                response.data = pages;
                return response;

            }
            catch (Exception ex)
            {
                response.message = "获取失败！意外错误：" + ex.Message;
                return response;
            }


        }
        public ApiResult<List<DepartmentResponse>> GetAllSchool()
        {
            ApiResult<List<DepartmentResponse>> response = new ApiResult<List<DepartmentResponse>>();
            try
            {
                var pages = Query().OrderByDescending(n => n.CreateTime).Select(n => new DepartmentResponse
                {
                    Guid = n.Guid.ToString(),
                    Name = n.Name
                }).ToList();
                response.success = true;
                response.message = "获取成功！";
                response.data = pages;
                return response;

            }
            catch (Exception ex)
            {
                response.message = "获取失败！意外错误：" + ex.Message;
                return response;
            }
        }


        public async Task<ApiResult<string>> SaveAsync(DepartmentRequest request)
        {
            ApiResult<string> response = new ApiResult<string>();
            try
            {
                Department baiPingSchool = new Department();
                if (!string.IsNullOrEmpty(request.guid))
                {
                    var sguid = Guid.Parse(request.guid);
                    baiPingSchool = Query().Where(n => n.Guid == sguid).FirstOrDefault();
                    if (baiPingSchool == null)
                    {
                        response.message = "修改失败，未找到对应的数据！";
                        return response;
                    }
                    baiPingSchool.Name = request.Name;
                    baiPingSchool.Overdue = request.Overdue;
                    _unitofwork.RegisterDirty(baiPingSchool);
                }
                else
                {
                    baiPingSchool.Name = request.Name;
                    baiPingSchool.Overdue = request.Overdue;
                    await _unitofwork.RegisterNewAsync(baiPingSchool);
                }
                var b = await _unitofwork.CommitAsync();
                response.success = b;
                response.message = b ? "保存成功！" : "保存失败！";
                return response;
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
                return response;
            }

        }

        public ApiResult<DepartmentResponse> GetDetail(Guid guid)
        {
            ApiResult<DepartmentResponse> response = new ApiResult<DepartmentResponse>();
            try
            {

                var school = Query().Where(n => n.Guid == guid)
                    .Select(n => new DepartmentResponse
                    {
                        CreateTime = n.CreateTime.ToString("yyyy-MM-dd HH:mm:ss"),
                        Guid = n.Guid.ToString(),
                        Overdue = n.Overdue,
                        Name = n.Name
                    }).FirstOrDefault();
                if (school == null)
                {
                    response.message = "未找到改数据！";
                    return response;
                }
                response.success = true;
                response.data = school;
                response.message = "获取成功！";
                return response;
            }
            catch (Exception ex)
            {
                response.message = "获取失败！意外错误:" + ex.Message;
                return response;
            }

        }

        public ApiResult<string> Delete(Guid guid)
        {
            ApiResult<string> response = new ApiResult<string>();
            try
            {

                var school = Query().Where(n => n.Guid == guid).FirstOrDefault();
                if (school == null)
                {
                    response.message = "未找到改数据！";
                    return response;
                }
                DeleteForge(school);
                var b = _unitofwork.Commit();
                response.success = b;
                response.message = b ? "删除成功！" : "删除失败！";
                return response;
            }
            catch (Exception ex)
            {
                response.message = "删除失败！意外错误:" + ex.Message;
                return response;
            }
        }
    }
}
