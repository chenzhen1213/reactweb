﻿
using Scaffold.AppService.Interfaces;
using Scaffold.AppService.Model.RequestModel;
using Scaffold.Domain;
using Scaffold.Domain.Model;
using EStart.DataBase.EF;
using EStart.DataBase.Event.Domian;
using EStart.Infrastructure.ClientData;
using QuestionBank.Infrastructure.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Scaffold.AppService.Model.Messaging;
using Scaffold.AppService.Model.ResponseModel;
using EStart.Infrastructure.Domain;
using Microsoft.EntityFrameworkCore;
using EStart.Infrastructure.Extensions;
using Scaffold.AppService.Extensions;
using Scaffold.AppService.Model.Models;

namespace Scaffold.AppService.Implements
{
    public partial class UserActionService : ServiceCore<UserAction>, IUserActionService
    {

        public UserActionService(
            ScaffoldDbContext context,
            EventDbContext eventDbContext
            ) : base(context, eventDbContext)
        {
        }

        public ApiResult<string> Delete(Guid guid)
        {
            ApiResult<string> response = new ApiResult<string>();
            try
            {

                var school = Query().Where(n => n.Guid == guid).FirstOrDefault();
                if (school == null)
                {
                    response.message = "未找到改数据！";
                    return response;
                }
                DeleteForge(school);
                var b = _unitofwork.Commit();
                response.success = b;
                response.message = b ? "删除成功！" : "删除失败！";
                return response;
            }
            catch (Exception ex)
            {
                response.message = "删除失败！意外错误:" + ex.Message;
                return response;
            }
        }

        public async Task<ApiResult<List<CheckModel>>> GetCheckModelAsync()
        {
            ApiResult<List<CheckModel>> response = new ApiResult<List<CheckModel>>();
            try
            {

                var check = await Query().Select(n => new CheckModel
                {
                    label = n.Name,
                    value = n.ID
                }).ToListAsync();
                response.success = true;
                response.data = check;
                response.message = "获取成功！";
                return response;
            }
            catch (Exception ex)
            {
                response.message = "获取失败！意外错误:" + ex.Message;
                return response;
            }
        }
        public ApiResult<UserActionModel> GetDetail(Guid guid)
        {
            ApiResult<UserActionModel> response = new ApiResult<UserActionModel>();
            try
            {

                var entity = Query().Where(n => n.Guid == guid)
                    .Select(n => new UserActionModel
                    {
                        CreateTime = n.CreateTime.ToString("yyyy-MM-dd HH:mm:ss"),
                        guid = n.Guid.ToString(),
                        Name = n.Name,
                        Parameter = n.Parameter,
                        Remark = n.Remark
                    }).FirstOrDefault();
                if (entity == null)
                {
                    response.message = "未找到改数据！";
                    return response;
                }
                response.success = true;
                response.data = entity;
                response.message = "获取成功！";
                return response;
            }
            catch (Exception ex)
            {
                response.message = "获取失败！意外错误:" + ex.Message;
                return response;
            }
        }

        public async Task<ApiResult<Page<UserActionModel>>> GetPagesAsync(UserActionPage request)
        {
            ApiResult<Page<UserActionModel>> response = new ApiResult<Page<UserActionModel>>();
            try
            {
                var pages = await Query()
                            .HasWhere(request.ActionName, n => n.Name.Contains(request.ActionName))
                            .Select(n => new UserActionModel
                            {
                                CreateTime = n.CreateTime.ToString("yyyy-MM-dd HH:mm:ss"),
                                guid = n.Guid.ToString(),
                                Name = n.Name,
                                Parameter = n.Parameter,
                                Remark = n.Remark
                            }).OrderByDescending(n => n.CreateTime).ToPageAsync(request.PageIndex, request.PageSize);

                response.success = true;
                response.message = "获取成功！";
                response.data = pages;
                return response;

            }
            catch (Exception ex)
            {
                response.message = "获取失败！意外错误：" + ex.Message;
                return response;
            }
        }



        public async Task<ApiResult<string>> SaveAsync(UserActionModel request)
        {
            ApiResult<string> response = new ApiResult<string>();
            try
            {
                if (string.IsNullOrEmpty(request.guid))
                {
                    UserAction model = new UserAction();

                    model.Parameter  = request.Parameter;
                    model.Remark = request.Remark;
                    model.Name = request.Name;
                    await _unitofwork.RegisterNewAsync(model);
                }
                else
                {
                    var sguid = Guid.Parse(request.guid);
                    var model = Query().Where(n => n.Guid == sguid).FirstOrDefault();
                    if (model == null)
                    {
                        throw new Exception("未找到修改数据！！");
                    }

                    model.Parameter = request.Parameter;
                    model.Remark = request.Remark;
                    model.Name = request.Name;
                    _unitofwork.RegisterDirty(model);

                }

                var b = await _unitofwork.CommitAsync();

                response.success = b;
                response.message = b ? "保存成功！" : "保存失败";
                return response;
            }
            catch (Exception ex)
            {

                response.message = "发生错误：" + ex.Message;
                return response;
            }
        }
    }
}
