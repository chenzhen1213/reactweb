﻿
using Scaffold.AppService.Interfaces;
using Scaffold.AppService.Model.RequestModel;
using Scaffold.Domain;
using Scaffold.Domain.Model;
using EStart.DataBase.EF;
using EStart.DataBase.Event.Domian;
using EStart.Infrastructure.ClientData;
using QuestionBank.Infrastructure.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Scaffold.AppService.Model.Messaging;
using Scaffold.AppService.Model.ResponseModel;
using EStart.Infrastructure.Domain;
using Microsoft.EntityFrameworkCore;
using EStart.Infrastructure.Extensions;
using Scaffold.AppService.Extensions;
using Scaffold.AppService.Model.Models;

namespace Scaffold.AppService.Implements
{
    public partial class UserInRoleGroupService : ServiceCore<UserInRoleGroup>, IUserInRoleGroupService
    {

        public UserInRoleGroupService(
            ScaffoldDbContext context,
            EventDbContext eventDbContext
            ) : base(context, eventDbContext)
        {
        }
    }
}
