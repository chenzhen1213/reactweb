﻿
using EStart.BootStrapper.IocConfiguration;
using EStart.DataBase.Event.Domian;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using MonkeyWhy.Domain;
using QuickApp.Domain;

namespace EStart.BootStrapper.Startup
{
    public static class OptionStartup
    {


        /// <summary>
        /// 初始化MonkeyWhy服务
        /// </summary>
        /// <param name="services"></param>
        /// <param name="connstring">上下文链接字符串</param>
        /// <param name="eventconnstring">事件日志链接字符串</param>
        /// <returns></returns>
        public static IServiceCollection MonkeyWhyInit(this IServiceCollection services, string connstring, string eventconnstring)
        {

            if (!string.IsNullOrEmpty(eventconnstring))
            {
                //配置事件日志数据库
                services.AddDbContext<EventDbContext>(options =>
                 options.UseSqlServer(eventconnstring, p => p.MigrationsAssembly("EStart.DataBase.Event.Domian")));
            }
            //配置DI容器
            MonkeyWhyIocConfiguration.AddIocConfiguration(services);

            services.AddDbContext<MonkeyWhyDbContext>(options =>
             options.UseSqlServer(connstring, p => p.MigrationsAssembly("MonkeyWhy.Domain")));

            return services;
        }

    }
}
