﻿using Microsoft.Extensions.DependencyInjection;
using MonkeyWhy.Application.Implements;
using MonkeyWhy.Application.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace EStart.BootStrapper.IocConfiguration
{
    public static class MonkeyWhyIocConfiguration
    {
        /// <summary>
        /// 注册DI服务
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddIocConfiguration(IServiceCollection services)
        {
            services.AddScoped<IUserService, UserService>();
            //services.AddTransient<IUserService, UserService>();
            services.AddTransient<ITagService, TagService>();
            services.AddTransient<IArticelAndTagService, ArticelAndTagService>();
            services.AddTransient<IArticleService, ArticleService>();
            //services.AddTransient<IQuestionService, QuestionService>();
            //services.AddTransient<IDomainEventPublisher, DomainEventPublisher>();
            //services.AddTransient<IDomainEventHandler<UserEvent>, EventHandlerTest>();
            //services.AddTransient<IDomainEventHandler<UserEvent>, EventHandlerCaching>();

            return services;
        }
    }
}
