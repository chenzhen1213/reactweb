﻿using EStart.Infrastructure.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scaffold.Domain.Model
{
    public class Department : EntityCore
    {
        /// <summary>
        /// 部门名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 回转期
        /// </summary>
        public int Overdue { get; set; }

        protected override void Validate()
        {
            //throw new NotImplementedException();
        }
    }
}
