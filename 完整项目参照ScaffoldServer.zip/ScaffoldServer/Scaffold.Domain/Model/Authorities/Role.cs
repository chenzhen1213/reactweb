using EStart.Infrastructure.Domain;
using System.Collections.Generic;

namespace Scaffold.Domain.Model
{

    /// <summary>
    /// ��ɫģ��
    /// </summary>
    public partial class Role : EntityCore
    {
        public virtual ICollection<UserMenuOrActionInRole> RoleAndMenu { get; set; }


        /// <summary>
        /// ��ɫ����
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// ��ע
        /// </summary>
        public string Remark { get; set; }

        protected override void Validate()
        {
            if (string.IsNullOrEmpty(Name))
                AddBrokenRule(new BusinessRule(nameof(Name), "��ɫ���Ʋ���Ϊ��."));
        }
    }
}
