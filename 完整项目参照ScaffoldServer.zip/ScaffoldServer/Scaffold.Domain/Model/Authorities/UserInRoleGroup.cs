using EStart.Infrastructure.Domain;

namespace Scaffold.Domain.Model
{
    /// <summary>
    /// �û����ɫ�����ģ��
    /// </summary>
    public partial class UserInRoleGroup : EntityCore
    {
        /// <summary>
        /// �û�ID
        /// </summary>
        public int UserID { get; set; }
        /// <summary>
        /// ��ɫ��ID
        /// </summary>
        public int RoleGroupID { get; set; }
        public virtual RoleGroup RoleGroup { get; set; }


        protected override void Validate()
        {
            if (RoleGroupID == 0)
                AddBrokenRule(new BusinessRule(nameof(RoleGroupID), "��ɫ����Ϣ����Ϊ��."));
            if (UserID == 0)
                AddBrokenRule(new BusinessRule(nameof(UserID), "�û���Ϣ����Ϊ��."));
        }
    }
}
