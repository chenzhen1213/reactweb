﻿using EStart.Infrastructure.Domain;

namespace Scaffold.Domain.Model
{
    /// <summary>
    /// 菜单与角色关联表
    /// </summary>
    public class UserMenuOrActionInRole : EntityCore
    {

        public virtual UserMenu UserMenu { get; set; }
        /// <summary>
        /// 菜单ID
        /// </summary>
        public int UserMenuID { get; set; }


        /// <summary>
        /// 动作ID
        /// </summary>
        public int UserActionID { get; set; }
        public virtual UserAction UserAction { get; set; }


        /// <summary>
        /// 父级菜单ID
        /// </summary>
        public int FatherMenuID { get; set; }


        /// <summary>
        /// 角色ID
        /// </summary>
        public int RoleID { get; set; }
        protected override void Validate()
        {
            if (UserMenuID == 0)
                AddBrokenRule(new BusinessRule(nameof(UserMenuID), "菜单信息不能为空."));
            if (RoleID == 0)
                AddBrokenRule(new BusinessRule(nameof(RoleID), "角色信息不能为空."));
        }
    }
}
