﻿using EStart.Infrastructure.Domain;

namespace Scaffold.Domain.Model
{
    /// <summary>
    /// 角色与角色组关联模型
    /// </summary>
    public class RoleInRoleGroup : EntityCore
    {
        /// <summary>
        /// 角色组ID
        /// </summary>
        public int RoleGroupID { set; get; }

        public virtual Role Role { get; set; }
        /// <summary>
        /// 角色ID
        /// </summary>
        public int RoleID { set; get; }

        /// <summary>
        /// 是否有这个权限
        /// </summary>
        public bool IsCheck { get; set; }

        protected override void Validate()
        {
            if (RoleGroupID == 0)
                AddBrokenRule(new BusinessRule(nameof(RoleGroupID), "角色组信息不能为空."));
            if (RoleID == 0)
                AddBrokenRule(new BusinessRule(nameof(RoleID), "角色信息不能为空."));
        }
    }
}
