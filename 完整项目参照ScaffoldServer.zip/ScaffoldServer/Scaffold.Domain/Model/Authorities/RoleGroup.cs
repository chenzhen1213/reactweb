﻿using EStart.Infrastructure.Domain;
using System.Collections.Generic;

namespace Scaffold.Domain.Model
{
    /// <summary>
    /// 角色组模型
    /// </summary>
    public class RoleGroup : EntityCore
    {
        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 角色组的数据等级
        /// </summary>
        public int RoleDataLevel { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }

        public virtual ICollection<RoleInRoleGroup> RoleAndRoleGroup { get; set; }

        protected override void Validate()
        {
            if (string.IsNullOrEmpty(Name))
                AddBrokenRule(new BusinessRule(nameof(Name), "角色组名称不能为空."));
        }
    }
}
