using EStart.Infrastructure.Domain;
using System.Collections.Generic;

namespace Scaffold.Domain.Model
{
    /// <summary>
    /// �û��˵�
    /// </summary>
    public partial class UserMenu : EntityCore
    {

        /// <summary>
        /// �ϼ��˵�ID
        /// </summary>
        public int? UserMenuID { get; set; }

        /// <summary>
        /// �˵�����
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// ����
        /// </summary>
        public string Introduce { get; set; }

        /// <summary>
        /// �˵�URL
        /// </summary>
        public string Url { get; set; }
        /// <summary>
        /// ͼ��
        /// </summary>
        public string Icon { get; set; }
        /// <summary>
        /// �Ƿ�չ��
        /// </summary>
        public bool Spread { get; set; }

        /// <summary>
        /// ����
        /// </summary>
        public int Sort { get; set; }

        /// <summary>
        /// �Ӳ˵��б�
        /// </summary>
        public virtual ICollection<UserMenu> UserMenuChild { get; set; }


        protected override void Validate()
        {
            if (string.IsNullOrEmpty(Name))
                AddBrokenRule(new BusinessRule(nameof(Name), "�˵����Ʋ���Ϊ��."));
            if (string.IsNullOrEmpty(Url))
                AddBrokenRule(new BusinessRule(nameof(Url), "�˵���ת��ַ����Ϊ��."));
        }
    }
}
