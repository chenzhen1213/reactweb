﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace Scaffold.Domain.Migrations
{
    public partial class InitTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Departments",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreateTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DataLevel = table.Column<int>(type: "int", nullable: false),
                    Guid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false),
                    LastChangeTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Overdue = table.Column<int>(type: "int", nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Departments", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "RoleGroups",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreateTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DataLevel = table.Column<int>(type: "int", nullable: false),
                    Guid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false),
                    LastChangeTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Remark = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RoleDataLevel = table.Column<int>(type: "int", nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RoleGroups", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Roles",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreateTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DataLevel = table.Column<int>(type: "int", nullable: false),
                    Guid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false),
                    LastChangeTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Remark = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Roles", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "UserActions",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreateTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DataLevel = table.Column<int>(type: "int", nullable: false),
                    Guid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false),
                    LastChangeTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Parameter = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Remark = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserActions", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "UserMenus",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreateTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DataLevel = table.Column<int>(type: "int", nullable: false),
                    Guid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Icon = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Introduce = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false),
                    LastChangeTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true),
                    Sort = table.Column<int>(type: "int", nullable: false),
                    Spread = table.Column<bool>(type: "bit", nullable: false),
                    Url = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserMenuID = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserMenus", x => x.ID);
                    table.ForeignKey(
                        name: "FK_UserMenus_UserMenus_UserMenuID",
                        column: x => x.UserMenuID,
                        principalTable: "UserMenus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AllowIPAddresses = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreateTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DataLevel = table.Column<int>(type: "int", nullable: false),
                    DepartmentID = table.Column<int>(type: "int", nullable: true),
                    Guid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    IPLimitEnabled = table.Column<bool>(type: "bit", nullable: false),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false),
                    LastChangeTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LockoutEnabled = table.Column<bool>(type: "bit", nullable: false),
                    LockoutEnd = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LoginName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Mobile = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RealName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Remark = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true),
                    Tel = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Users_Departments_DepartmentID",
                        column: x => x.DepartmentID,
                        principalTable: "Departments",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "RoleInRoleGroups",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreateTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DataLevel = table.Column<int>(type: "int", nullable: false),
                    Guid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    IsCheck = table.Column<bool>(type: "bit", nullable: false),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false),
                    LastChangeTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    RoleGroupID = table.Column<int>(type: "int", nullable: false),
                    RoleID = table.Column<int>(type: "int", nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RoleInRoleGroups", x => x.ID);
                    table.ForeignKey(
                        name: "FK_RoleInRoleGroups_RoleGroups_RoleGroupID",
                        column: x => x.RoleGroupID,
                        principalTable: "RoleGroups",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "UserMenuOrActionInRoles",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreateTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DataLevel = table.Column<int>(type: "int", nullable: false),
                    FatherMenuID = table.Column<int>(type: "int", nullable: false),
                    Guid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false),
                    LastChangeTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    RoleID = table.Column<int>(type: "int", nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true),
                    UserActionID = table.Column<int>(type: "int", nullable: false),
                    UserMenuID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserMenuOrActionInRoles", x => x.ID);
                    table.ForeignKey(
                        name: "FK_UserMenuOrActionInRoles_Roles_RoleID",
                        column: x => x.RoleID,
                        principalTable: "Roles",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_UserMenuOrActionInRoles_UserActions_UserActionID",
                        column: x => x.UserActionID,
                        principalTable: "UserActions",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_UserMenuOrActionInRoles_UserMenus_UserMenuID",
                        column: x => x.UserMenuID,
                        principalTable: "UserMenus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "UserInRoleGroups",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreateTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DataLevel = table.Column<int>(type: "int", nullable: false),
                    Guid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false),
                    LastChangeTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    RoleGroupID = table.Column<int>(type: "int", nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true),
                    UserID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserInRoleGroups", x => x.ID);
                    table.ForeignKey(
                        name: "FK_UserInRoleGroups_RoleGroups_RoleGroupID",
                        column: x => x.RoleGroupID,
                        principalTable: "RoleGroups",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_UserInRoleGroups_Users_UserID",
                        column: x => x.UserID,
                        principalTable: "Users",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_RoleInRoleGroups_RoleGroupID",
                table: "RoleInRoleGroups",
                column: "RoleGroupID");

            migrationBuilder.CreateIndex(
                name: "IX_UserInRoleGroups_RoleGroupID",
                table: "UserInRoleGroups",
                column: "RoleGroupID");

            migrationBuilder.CreateIndex(
                name: "IX_UserInRoleGroups_UserID",
                table: "UserInRoleGroups",
                column: "UserID");

            migrationBuilder.CreateIndex(
                name: "IX_UserMenuOrActionInRoles_RoleID",
                table: "UserMenuOrActionInRoles",
                column: "RoleID");

            migrationBuilder.CreateIndex(
                name: "IX_UserMenuOrActionInRoles_UserActionID",
                table: "UserMenuOrActionInRoles",
                column: "UserActionID");

            migrationBuilder.CreateIndex(
                name: "IX_UserMenuOrActionInRoles_UserMenuID",
                table: "UserMenuOrActionInRoles",
                column: "UserMenuID");

            migrationBuilder.CreateIndex(
                name: "IX_UserMenus_UserMenuID",
                table: "UserMenus",
                column: "UserMenuID");

            migrationBuilder.CreateIndex(
                name: "IX_Users_DepartmentID",
                table: "Users",
                column: "DepartmentID");


            #region 部门  
            string[] departMent = new string[8] { "ID", "Guid", "CreateTime", "DataLevel", "IsDelete", "LastChangeTime", "Overdue", "Name" };
            string[] departValue = new string[8] { "1", Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(), "30", "默认部门" };
            migrationBuilder.InsertData("Departments", departMent, departValue);
            #endregion
            #region 用户  
            string[] userCol = new string[] { "ID", "Guid", "CreateTime", "DataLevel", "IsDelete", "LastChangeTime",
               "DepartmentID", "IPLimitEnabled", "LockoutEnabled", "LockoutEnd" ,"LoginName","Password","RealName"};
            string[] uservalue = new string[] {
                "1",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "1","False","False",DateTime.Now.ToString(),"admin","jYdKPH2VZVI=","管理员"
            };
            migrationBuilder.InsertData("Users", userCol, uservalue);
            #endregion
            #region 角色组
            string[] roleGroupCol = new string[] { "ID", "Guid", "CreateTime", "DataLevel", "IsDelete", "LastChangeTime",
               "RoleDataLevel", "Name"};
            string[] roleGroupValue = new string[] {
                "1",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "5","管理员组"
            };
            migrationBuilder.InsertData("RoleGroups", roleGroupCol, roleGroupValue);
            #endregion
            #region 角色
            string[] roleCol = new string[] { "ID", "Guid", "CreateTime", "DataLevel", "IsDelete", "LastChangeTime",
               "Name"};
            string[] roleValue = new string[] {
                "1",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "管理员"
            };
            migrationBuilder.InsertData("Roles", roleCol, roleValue);
            #endregion
            #region 菜单
            string[] menuCol = new string[] { "ID", "Guid", "CreateTime", "DataLevel", "IsDelete", "LastChangeTime",
               "Name","Url","UserMenuID","Sort","Spread"};
            string[] menuValue = new string[] {
                "1",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "基础数据","",null,"1","False"
            };
            migrationBuilder.InsertData("UserMenus", menuCol, menuValue);
            menuValue = new string[] {
                "2",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "权限管理","",null,"2","False"
            };
            migrationBuilder.InsertData("UserMenus", menuCol, menuValue);
            menuValue = new string[] {
                "3",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "部门管理","/department","1","1","False"
            };
            migrationBuilder.InsertData("UserMenus", menuCol, menuValue);
            menuValue = new string[] {
                "4",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "用户管理","/user","2","2","False"
            };
            migrationBuilder.InsertData("UserMenus", menuCol, menuValue);
            menuValue = new string[] {
                "5",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "角色组管理","/rolegroup","2","3","False"
            };
            migrationBuilder.InsertData("UserMenus", menuCol, menuValue);
            menuValue = new string[] {
                "6",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "角色管理","/role","2","4","False"
            };
            migrationBuilder.InsertData("UserMenus", menuCol, menuValue);
            menuValue = new string[] {
                "7",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "菜单管理","/usermenu","2","5","False"
            };
            migrationBuilder.InsertData("UserMenus", menuCol, menuValue);

            menuValue = new string[] {
                "8",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "动作管理","/useraction","2","6","False"
            };
            migrationBuilder.InsertData("UserMenus", menuCol, menuValue);
            #endregion
            #region 动作
            string[] actionCol = new string[] { "ID", "Guid", "CreateTime", "DataLevel", "IsDelete", "LastChangeTime",
               "Name","Parameter"};
            string[] actionValue = new string[] {
                "1",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "新增","create"
            };
            migrationBuilder.InsertData("UserActions", actionCol, actionValue);

            actionValue = new string[] {
                "2",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "修改","update"
            };
            migrationBuilder.InsertData("UserActions", actionCol, actionValue);

            actionValue = new string[] {
                "3",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "删除","delete"
            };
            migrationBuilder.InsertData("UserActions", actionCol, actionValue);

            actionValue = new string[] {
                "4",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "菜单绑定","menubind"
            };
            migrationBuilder.InsertData("UserActions", actionCol, actionValue);



            #endregion
            #region  用户绑定用户组
            string[] userinroleCol = new string[] { "ID", "Guid", "CreateTime", "DataLevel", "IsDelete", "LastChangeTime",
               "RoleGroupID","UserID"};
            string[] userinroleValue = new string[] {
                "1",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "1","1"
            };
            migrationBuilder.InsertData("UserInRoleGroups", userinroleCol, userinroleValue);
            #endregion
            #region  角色组绑定角色
            string[] rolegroupinroleCol = new string[] { "ID", "Guid", "CreateTime", "DataLevel", "IsDelete", "LastChangeTime",
               "IsCheck","RoleGroupID","RoleID"};
            string[] rolegroupinroleValue = new string[] {
                "1",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "False","1","1"
            };
            migrationBuilder.InsertData("RoleInRoleGroups", rolegroupinroleCol, rolegroupinroleValue);
            #endregion
            #region  角色绑定菜单
            string[] roleinmenuCol = new string[] { "ID", "Guid", "CreateTime", "DataLevel", "IsDelete", "LastChangeTime",
               "RoleID","UserActionID","UserMenuID","FatherMenuID"};
            string[] roleinmenuValue = new string[] {
                "1",Guid.NewGuid().ToString(), DateTime.Now.ToString(), "1", "False", DateTime.Now.ToString(),
                "1","4","6","2"
            };
            migrationBuilder.InsertData("UserMenuOrActionInRoles", roleinmenuCol, roleinmenuValue);
            #endregion
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "RoleInRoleGroups");

            migrationBuilder.DropTable(
                name: "UserInRoleGroups");

            migrationBuilder.DropTable(
                name: "UserMenuOrActionInRoles");

            migrationBuilder.DropTable(
                name: "RoleGroups");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Roles");

            migrationBuilder.DropTable(
                name: "UserActions");

            migrationBuilder.DropTable(
                name: "UserMenus");

            migrationBuilder.DropTable(
                name: "Departments");
        }
    }
}
