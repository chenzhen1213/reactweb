﻿using EStart.Infrastructure.Engines;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace EStart.Infrastructure.Domain.Events
{
    public class DomainEventHandlerFactory
    {
        public static IEnumerable<IDomainEventHandler<T>> GetDomainEventHandlersFor<T>(T domainEvent)
            where T : IDomainEvent
        {
            return EngineContainerFactory.GetContainer().GetAllInstances<IDomainEventHandler<T>>();
        }
    }
}
