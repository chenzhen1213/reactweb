﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EStart.Infrastructure.Domain.Events
{
    /// <summary>
    /// 领域事件统一接口
    /// </summary>
    public interface IDomainEvent
    {
    }
}
