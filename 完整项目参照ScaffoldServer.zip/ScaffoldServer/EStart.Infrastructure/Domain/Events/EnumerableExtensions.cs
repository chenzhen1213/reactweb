﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EStart.Infrastructure.Domain.Events
{
    public static class EnumerableExtensions
    {
        public static void ForEach<T>(this IEnumerable<T> source, Action<T> action)
        {
            foreach (var item in source)
                action(item);
        }
    }
}
